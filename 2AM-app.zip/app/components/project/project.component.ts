import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Project } from '../../project';
import { ProjectService } from '../../project.service';
import { User } from '../../user';
import { UserService } from '../../user.service';
import { Location } from '@angular/common';
import { FilterPipe } from '../../filter.pipe';
import { Observable } from 'rxjs/Observable';
import {debounceTime, map} from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})

export class ProjectComponent implements OnInit {
  constructor(private userService: UserService, private projectService: ProjectService,
    private location: Location) { }

    project = new Project();
    submitted = false;
    sortval : any ;
    message: string;
    projectList: Project[];
    getCheckID  : any;

  search:any;
  formatter:any;
  selectedParent:{_id:string, first_name:string} = null;
  clickedItem:string;
  usersResult:{_id:string, first_name:string}[];
  
  ngOnInit() {
    this.getProjects(this.sortval);
    this.ngBootstrapTypeahead();
    this.getUser();
  }

  getUser()
  {
    return this.userService.getUsersList()
    .subscribe(
      (data: any) => {
        this.usersResult = data;
        console.log(this.usersResult);
      });
  }


  ngBootstrapTypeahead(){
    this.search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
      : this.usersResult.filter(tr => tr.first_name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    );
    
    this.formatter = (x: {first_name: string}) => {
      // // console.log(x);
      return x.first_name;
    };  
    
  }



  selectedItem(item){
    this.clickedItem=item.item._id;
    console.log('here we go');
    console.log(this.clickedItem);
  }


 addProject() {
   this.submitted = true;
   this.projectService.saveProject(this.project)
   .subscribe(()=> this.message = "Project Added Successfully!");
 }

 updateProject() {
  this.submitted = true;
  this.projectService.updateProject(this.getCheckID,this.project)
  .subscribe(()=> this.message = "Project Updated Successfully!");
}

deleteProject(id) {
  this.submitted = true;
  this.projectService.deleteProject(id)
  .subscribe(()=> this.message = "Project Deleted Successfully!");
}

 findbyID(id)
 { 
   this.getCheckID = id;
     this.projectService.getProjectsById(id)
      .subscribe(project => this.project = project);
 }

 getProjects(val) 
 {
  this.sortval = val;
    if(this.sortval) 
    {
          return this.projectService.getSortedProjectsList(this.sortval)
        .subscribe(
        projectList => {
        console.log(projectList);
        this.projectList = projectList;
        });
    }
    else
    {
        return this.projectService.getProjectsList()
        .subscribe(
        projectList => {
        console.log(projectList);
        this.projectList = projectList;
        });
    }
}
}
