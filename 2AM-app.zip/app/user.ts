export class User {
    first_name: string;
    last_name: string;
    employee_id: number;
}
