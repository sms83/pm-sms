import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';;

// Componenets
import { AppComponent } from './app.component';
import { UserComponent } from './components/user/user.component';
import { ProjectComponent } from './components/project/project.component';
import { TaskComponent } from './components/task/task.component';

import { FormsModule }   from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { FilterPipe} from './filter.pipe';

// Addind Routes
import { RouterModule, Routes } from '@angular/router';
const routes:Routes = [
  {path: 'user', component: UserComponent},
  { path: 'project',component: ProjectComponent},
  { path: 'task',component: TaskComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    ProjectComponent,
    TaskComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FormsModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [],
    schemas : [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
