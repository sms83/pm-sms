import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import {debounceTime, map} from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Task } from './../model/Task';
import { TaskService } from '../task.service';
import { Project } from '../../../project';
import { ProjectService } from '../../../project.service';
import { User } from '../../../user';
import { UserService } from '../../../user.service';
import { Location } from '@angular/common';
import { FilterPipe } from '../../../filter.pipe';
import { FindtasknamePipe } from '../../../findtaskname.pipe'; 

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  starting_date:any = {};
  ending_date:any = {};

  // Task
 /* task: Task = new Task();
  parentsTask:{_id:string, task:string}[];
  searchParentTask:any;
  formatterParentTask:any;
  selectedParentTask:{_id:string, task:string} = null;

    // User
    user: User = new User();
    parents:{_id:string, task:string}[];
    search:any;
    formatter:any;
    selectedParent:{_id:string, task:string} = null;
  */
  // Project
  taskObj = new Task();
  submitted = false;
  sortval : any ;
  message: string;
  projectList: Project[];
  getCheckID  : any;
 
search:any;
formatter:any;
selectedParent:{_id:string, first_name:string} = null;
clickedItem:string;
usersResult:{_id:string, first_name:string}[];

  constructor(private userService: UserService, private projectService: ProjectService, private router: Router) { }

  ngOnInit() {
    this.getProjects();
    this.getUser();
   // this.TypeaheadTaskSearch();
   // this.TypeaheadUserSearch();
    this.TypeaheadProjectSearch();
    
   }
  
   getUser()
   {
     return this.userService.getUsersList()
     .subscribe(
       (data: any) => {
         this.usersResult = data;
         console.log(this.usersResult);
       });
   }

   getProjects()
   {
     return this.projectService.getProjectsList()
     .subscribe(
      (data: any) => {
        this.projectList = data;
        console.log(this.projectList);
      });
   }

   TypeaheadProjectSearch(){
    this.search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
      : this.usersResult.filter(tr => tr.first_name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    );
    
    this.formatter = (x: {first_name: string}) => {
      // // console.log(x);
      return x.first_name;
    };  
  }
   TypeaheadTaskSearch(){
   /* this.searchParentTask = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
      : this.parentsTask.filter(
        parent => parent.task.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      );
      this.formatterParentTask = (x: {task: string}) => {
       return x.task;
      };  */
  }

  TypeaheadUserSearch(){
   /* this.search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
      : this.parents.filter(
        parent => parent.task.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      );
      this.formatter = (x: {task: string}) => {
       return x.task;
      };  */
  }

  /*
  
  findAllTasks(){
    this.taskService.getAllTasks()
    .subscribe((res: any)=>{
      // console.log(res);
      if(res.success == true){
        this.parents = res.data;
      } else {
        // console.log("error in finding all tasks");
      }
    })
  }

  changePriority(p){
    // console.log(p);
    this.task.priority = p;
  }

  addTask(){

    this.task.end_date = new Date(`${this.ending_date.year}/${this.ending_date.month}/${this.ending_date.day}`);
    this.task.start_date = new Date(`${this.starting_date.year}/${this.starting_date.month}/${this.starting_date.day}`);

    // console.log(this.task);
    // console.log(this.selectedParent);

    if(!!this.selectedParent){
      this.task.parent_id = this.selectedParent._id;
    }

    this.taskService.createTask(this.task)
    .subscribe((res: any)=>{
      // console.log(res);
      if(res.success == true){
        // console.log('valid')
        this.router.navigate(['/', 'view']);
      } else {
        alert('Invalid user');
      }
    })

  }*/
}
