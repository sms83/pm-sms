import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { UtilService } from '../util.service';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

	host = "http://localhost:4000";
  constructor(private http: HttpClient) { 
    // console.log(this.util.host);
  }

  getAllTasks(){
    return this.http.get(`${this.host}/tasks/tasks`);
  }
  getTask(taskId){
    return this.http.get(`${this.host}/tasks/tasks/${taskId}`);
  }
  createTask(task){
    return this.http.post(`${this.host}/tasks/tasks`, task);
  }
  updateTask(taskId, task){
    return this.http.put(`${this.host}/tasks/tasks/${taskId}`, task);
  }
  deleteTask(taskId){
    return this.http.delete(`${this.host}/tasks/tasks/${taskId}`);
  }

}
