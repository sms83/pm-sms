var mongoose = require('mongoose');
//const Schema = mongoose.Schema;

projectSchema = new mongoose.Schema({
    project: {type: String, required: true, unique: true, dropDups: true},
    start_date : {type: Date, required: true},
    end_date: {type: Date, required: true},
    priority : {type: Number, required: true},
    manager :{ type: mongoose.Schema.Types.ObjectId,ref: 'User', required: true}
  })

module.exports = mongoose.model('Project', projectSchema);