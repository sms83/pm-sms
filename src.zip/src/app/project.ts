export class User {
    project: string;
    start_date: string;
    end_date: number;
    priority: number;
    manager: string;
}
