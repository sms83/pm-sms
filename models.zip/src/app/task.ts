export class Task {
    project: string;
    task: string;
    priority: number;   
    parent_task: string;
    start_date: string;
    end_date: number;
    user: string;
}
