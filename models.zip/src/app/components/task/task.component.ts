import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Task } from '../../task';
import { TaskService } from '../../task.service';
import { Location } from '@angular/common';
import { FilterPipe } from '../../filter.pipe';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  constructor(private taskService: TaskService,
    private location: Location) { }

    task = new Task();
    submitted = false;
    sortval : any ;
    message: string;
    taskList: Task[];
    getCheckID  : any;

  ngOnInit() {
    this.getTasks(this.sortval);
    this.ngbdTypeaheadTemplate();
  }


  search:any;
  formatter:any;
  selectedParent:{_id:string, task:string} = null;
  clickedItem:string;
  tasksResult:{_id:string, task:string}[];
  
  ngbdTypeaheadTemplate() 
  {
    this.formatter = (x: {task: string}) => {
      console.log(x);
      return x.task;
    }; 
    this.search = (text$: Observable<string>) => text$
    .debounceTime(200)
    .distinctUntilChanged()
    .map(term => term === '' ? []
      : this.tasksResult.filter(tr => tr.task.toLowerCase().indexOf(term.toLowerCase()) > -1));
  }

  selectedItem(item){
    this.clickedItem=item.item._id;
    console.log('here we go');
    console.log(this.clickedItem);
  }


 addTask() {
   this.submitted = true;
   this.taskService.saveTask(this.task)
   .subscribe(()=> this.message = "Task Added Successfully!");
 } 

 updateTask() {
  this.submitted = true;
  this.taskService.updateTask(this.getCheckID,this.task)
  .subscribe(()=> this.message = "Task Updated Successfully!");
}

deleteTask(id) {
  this.submitted = true;
  this.taskService.deleteTask(id)
  .subscribe(()=> this.message = "Task Deleted Successfully!");
}

 findbyID(id)
 { 
   this.getCheckID = id;
     this.taskService.getTasksById(id)
      .subscribe(task => this.task = task);
 }

 getTasks(val) 
 {
  this.sortval = val;
    if(this.sortval) 
    {
          return this.taskService.getSortedTasksList(this.sortval)
        .subscribe(
        taskList => {
        console.log(taskList);
        this.taskList = taskList;
        });
    }
    else
    {
        return this.taskService.getTasksList()
        .subscribe(
        taskList => {
        console.log(taskList);
        this.taskList = taskList;
        });
    }
}

}
