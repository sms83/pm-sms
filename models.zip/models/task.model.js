var mongoose = require('mongoose');
//const Schema = mongoose.Schema;

taskSchema = new mongoose.Schema({
    project :{ type: mongoose.Schema.Types.ObjectId,ref: 'Project', required: true},
    task: {type: String, required: true, unique: true, dropDups: true},
    priority : {type: Number, required: true},
    start_date : {type: Date, required: true},
    end_date: {type: Date, required: true},
    user :{ type: mongoose.Schema.Types.ObjectId,ref: 'User', required: true},
 })

module.exports = mongoose.model('Task', taskSchema);

