var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Task = require('../models/task.model');

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

/* SAVE Project */
router.post('/saveTask', function(req, res, next) {
  Task.create(req.body, function (err, resutLists) {
    if(err){
      console.log(err);
    }
    else {
      res.json(resutLists);
    }
  });
});



router.get('/taskList', function(req, res, next) {
  Task.find(function (err, products) {
    if (err) return next(err);
    res.json(products);
  });
});


router.get('/tasks/:id', function (req, res) {
  // Task.find({_id: req.params.id}, function (err, docs) {
  //   if (err) {
  //     console.log(err);
  //     res.json({ success: false })
  //   } else {
  //     res.json({ success: true, data: docs[0] });
  //   }
  // });

  Task.findOne({ _id: req.params.id })
    .exec()
    .then(function (task) {
      if (task) {
        res.json({ success: true, data: task });
      } else {
        res.status(404).json({ success: false, message: "Task not found" });
      }
    })
    .catch(err => {
      console.log(err)
      res.status(500).json({
        success: false, message: err.message
      });
    });
})
router.put('/tasks/:id', function (req, res) {
  let task = req.body;
  delete task._id;

  Task.updateOne({ _id: req.params.id }, task, function (err) {
    if (err) { 
      res.json({success: false, message: err.message})
     } else {
       res.status(201).json({success: true});
     }
  })
})
router.delete('/tasks/:id', function (req, res) {
  Task.deleteOne({ _id:req.params.id }, function(err){
    if(err){
      res.json({success: false, message: err.message})
    } else {
      res.json({success: true});
    }
  })
})



module.exports = router;
