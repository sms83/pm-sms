export class Task {
    project: string;
    task: string;
    priority: number;   
    parent_task: string;
    start_date: Date;
    end_date: Date;
    user: string;
}


