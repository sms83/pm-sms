import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import {debounceTime,distinctUntilChanged, map} from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Task } from '../../../task';
import { TaskService } from '../../../task.service';
import { Project } from '../../../project';
import { ProjectService } from '../../../project.service';
import { User } from '../../../user';
import { UserService } from '../../../user.service';
import { Location } from '@angular/common';
import { FilterPipe } from '../../../filter.pipe';
import { FindtasknamePipe } from '../../../findtaskname.pipe'; 

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  tasks:Task[];
  tasksResult : any;
  constructor(private taskService:TaskService, 
    private userService: UserService, 
    private projectService: ProjectService, 
    private router: Router) { }


  usersResult : any;
  projectsResult : any;

  ngOnInit() {
    this.findAllTasks();
    this.getProjects();
    this.getUser();
   
  }

  findAllTasks(){
     return this.taskService.getTasksList().subscribe(
      tasksResult => {
    console.log(tasksResult);
    this.tasksResult = tasksResult;
    });
  }

  getUser()
  {
    return this.userService.getUsersList()
    .subscribe(
      (data: any) => {
        this.usersResult = data;
        console.log(this.usersResult);
      });
  }

  getProjects()
  {
    return this.projectService.getProjectsList()
    .subscribe(
     (data: any) => {
       this.projectsResult = data;
       console.log(this.projectsResult);
     });
  }

}
