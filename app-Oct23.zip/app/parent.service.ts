import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Parent } from './parent';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}; 

@Injectable({
  providedIn: 'root'
})
export class ParentService {

  constructor(private http: HttpClient) { }

  private parentUrl = 'http://localhost:4000/parents';  // URL to web api

  saveParent (parent: Parent): Observable<Parent> {
    return this.http.post<Parent>(this.parentUrl+'/saveParent', parent);
  }
  
}
